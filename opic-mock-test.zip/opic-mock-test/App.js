// App.js
import React, { useEffect } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import PermissionGate from './src/components/PermissionGate';
import TestScreen from './src/screens/TestScreen';

/**
 * [4. 안드로이드 기기 특화 제약 조건]
 * "시험이 진행되는 40분 동안 디바이스 화면이 절대 꺼지지 않도록 Wake Lock을 유지할 것"
 *
 * PermissionGate가 RECORD_AUDIO 권한을 먼저 확보한 뒤에만
 * TestScreen(실제 시험 화면)을 렌더링합니다.
 */
export default function App() {
  useEffect(() => {
    activateKeepAwakeAsync('opic-exam-session');
    return () => {
      deactivateKeepAwake('opic-exam-session');
    };
  }, []);

  return (
    <SafeAreaProvider>
      <PermissionGate>
        <TestScreen />
      </PermissionGate>
    </SafeAreaProvider>
  );
}
