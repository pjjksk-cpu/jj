# OPIc Mock Test App — 1단계 (프로젝트 셋업 + 반응형 UI + KeepAwake)

## 1. 프로젝트 초기화

```bash
npx create-expo-app opic-mock-test
cd opic-mock-test

# 이 저장소의 파일들(App.js, app.json, src/ 등)을 그대로 덮어씌우세요.

npx expo install expo-av expo-keep-awake expo-file-system expo-screen-orientation react-native-safe-area-context
```

> `expo install`을 사용해야 현재 Expo SDK 버전과 호환되는 패키지 버전이 자동으로 맞춰집니다.
> (직접 `npm install`을 쓰면 버전 불일치로 빌드 에러가 날 수 있습니다.)

## 2. 안드로이드 실행

```bash
# 개발 빌드(Expo Go로는 일부 네이티브 권한 동작이 제한적일 수 있어
# 실제 마이크 녹음 테스트 전에는 dev build 권장)
npx expo run:android

# 또는 Expo Go로 빠른 UI 확인
npx expo start --android
```

## 3. 폴더 구조

```
opic-mock-test/
├── App.js                          # 엔트리, KeepAwake 활성화
├── app.json                        # 안드로이드 권한(RECORD_AUDIO 등) 설정
├── babel.config.js
├── package.json
└── src/
    ├── constants/
    │   └── testConstants.js        # 상태 머신 enum, 15문항/40분/5초 등 상수
    ├── hooks/
    │   └── useResponsive.js        # 태블릿/폰, 가로/세로 감지
    ├── styles/
    │   └── theme.js                # 색상/간격/폰트 디자인 토큰
    ├── components/
    │   ├── Header.js               # 상단 타이머 + 문항 번호
    │   ├── ExaminerSection.js      # 중앙 Ava 아바타 + 상태 애니메이션
    │   ├── ProgressIndicator.js    # 1~15 진행도 (사이드/하단 반응형)
    │   └── ControlButtons.js       # Play/Replay/Next 버튼
    └── screens/
        └── TestScreen.js           # 전체 화면 조립
```

## 4. 이번 단계에서 구현된 것

- ✅ 태블릿(≥600dp) / 모바일 자동 감지, 회전 시 실시간 레이아웃 전환
  - 태블릿 가로모드: 진행도(1~15)를 화면 **우측 세로 사이드바**로 배치
  - 그 외(폰, 태블릿 세로모드): 진행도를 화면 **하단 가로 스크롤**로 배치
- ✅ 상단 40:00 카운트다운 타이머 UI + 문항 번호 (`Question N of 15`)
  - 5분 이하로 남으면 자동으로 경고색(빨강) 전환되는 스타일 준비 완료
- ✅ 중앙 Ava 아바타 + 상태별(WAIT/PLAYING/REPLAY_WINDOW/RECORDING) 컬러·펄스 애니메이션
- ✅ Play(▶) / Replay(↺) / Next(❯) 터치 친화적 버튼 (최소 88~120dp 높이)
  - 상태에 따른 활성/비활성 규칙을 `getEnabledButtons()`에 이미 반영
  - Replay에는 "남은 초" 배지를 표시할 수 있는 자리 마련 (2단계에서 카운트다운 연결)
- ✅ `App.js`에서 `expo-keep-awake`로 화면 꺼짐 방지 활성화/해제 처리
- ✅ `app.json`에 안드로이드 `RECORD_AUDIO`, `WAKE_LOCK` 권한 사전 선언

## 5. 다음 단계(2단계) 예고

`TestScreen.js`의 `handlePlay / handleReplay / handleNext`는 현재 로컬 state만 바꾸는
**더미 함수**입니다. 2단계에서는 이 자리에 다음을 연결합니다.

1. `expo-av`의 `Audio.requestPermissionsAsync()`로 마이크 권한 요청 (앱 최초 실행 시)
2. `Audio.Sound`로 문제 음성 재생 → 재생 완료(`onPlaybackStatusUpdate`의 `didJustFinish`) 감지
3. 재생 완료 즉시 5초 `setTimeout`/`setInterval` 기반 Replay Window 타이머 시작
4. 5초 경과 또는 Replay 클릭 시 `Audio.Recording`으로 즉시 녹음 시작
5. 전체 40분 카운트다운을 위한 최상위 타이머 (`useRef` + `setInterval`, 1초마다 감소)
6. 7번 문항 Next 시 난이도 조정 모달, 40분 초과 시 강제 종료 화면 분기

---

# 2단계 — 권한 처리 + 오디오 재생/녹음 + 상태 머신

## 새로 추가된 파일

```
src/
├── hooks/
│   ├── useAudioPermissions.js   # RECORD_AUDIO 권한 요청/재요청/설정 이동 분기
│   ├── useExamTimer.js          # 전체 40분 카운트다운 (1초 간격)
│   └── useTestStateMachine.js   # 핵심 상태 머신 (재생/5초 리플레이/녹음/저장/모달/강제종료)
├── constants/
│   └── questionData.js          # 15문항 오디오 소스 정의 (배포 전 실제 파일로 교체 필요)
└── components/
    ├── DifficultyModal.js       # 7번 문항 후 Easier/Similar/Harder 팝업
    ├── PermissionGate.js        # 마이크 권한 승인 전까지 시험 화면 진입 차단
    └── ForceEndScreen.js        # 40분 초과 시 강제 종료 화면
```

## 상태 전이가 실제로 동작하는 방식

1. **WAIT → PLAYING**: `ControlButtons`의 Play 클릭 → `useTestStateMachine.playQuestionAudio()`가
   `Audio.Sound.createAsync(question.audioSource, { shouldPlay: true })`로 재생 시작.
2. **PLAYING → REPLAY_WINDOW**: `setOnPlaybackStatusUpdate`의 `status.didJustFinish`를 감지해
   `startReplayWindow()` 호출 → `REPLAY_WINDOW_SECONDS(5)`부터 1초 간격 `setInterval`로 카운트다운.
   - `ControlButtons`의 Replay 버튼 배지에 남은 초가 실시간 표시됩니다.
3. **REPLAY_WINDOW → RECORDING**:
   - 5초 내 Replay 터치 시 `replayQuestionAudio()` → 2차 재생 종료 후 `startRecording()`.
   - 5초 경과 시 인터벌 콜백이 자동으로 `startRecording()` 호출.
4. **RECORDING**: `Audio.Recording` 인스턴스를 `prepareToRecordAsync` → `startAsync`로 즉시 시작.
   Next 버튼만 활성화됩니다.
5. **RECORDING → 저장 → 다음 문항 WAIT**: `handleNext()`가 `stopAndUnloadAsync()`로 녹음을 종료하고,
   `expo-file-system`으로 `documentDirectory/opic_recordings/q{N}_{timestamp}.m4a` 경로에 이동/저장.
   - **7번 문항**이면 바로 다음으로 넘어가지 않고 `showDifficultyModal = true`로 전환,
     사용자가 Easier/Similar/Harder를 선택해야 8번으로 진행됩니다.
6. **40분 초과**: `useExamTimer`의 `onExpire` 콜백이 `forceEndExam()`을 호출 →
   진행 중이던 recording을 즉시 `stopAndUnloadAsync()`로 중지하고 `isForceEnded = true`로 전환,
   `TestScreen`이 `ForceEndScreen`으로 즉시 교체 렌더링됩니다.

## 마이크 권한 흐름

- `App.js` → `PermissionGate`가 마운트되면서 `useAudioPermissions`가 자동으로
  `Audio.requestPermissionsAsync()`를 호출합니다.
- **승인**: `TestScreen`(및 40분 타이머)이 렌더링/시작됩니다.
- **거부(재요청 가능)**: "마이크 권한 허용" 버튼으로 재요청.
- **거부(다시 묻지 않음)**: "설정에서 권한 허용하기" 버튼으로 `Linking.openSettings()` 이동.

## 실행 전 꼭 확인할 것

1. `src/constants/questionData.js`의 `audioSource`를 실제 문항 음성 파일(로컬 asset 또는
   원격 URL)로 교체해야 재생이 정상 동작합니다. (현재는 예시 placeholder URL)
2. Expo Go에서는 마이크 녹음/일부 파일시스템 동작이 제한적일 수 있으므로,
   실기기 테스트는 `npx expo run:android` (dev build) 기준으로 진행하세요.
3. 저장된 녹음 파일 목록은 `useTestStateMachine`이 반환하는 `savedRecordings`
   (`[{ questionNumber, uri }]`)에서 확인 가능하며, 이 배열이 3단계(업로드 로직)의 입력값이 됩니다.

---

# 3단계 — 로컬 결과 화면 (서버/Firebase 없이 바로 실행)

사용자가 "모바일/태블릿에서 바로 실행"만 원하는 경우, 외부 백엔드 없이도
완결된 경험을 주기 위해 **로컬 재생 + 안드로이드 공유시트 내보내기** 방식으로 구현했습니다.

## 새로 추가/변경된 파일

```
src/screens/
├── TestScreen.js     # (변경) 세션 래퍼로 리팩토링 — sessionKey로 재시작 시 완전 초기화
└── ResultScreen.js   # (신규) 결과 화면 — 문항별 재생 + 공유하기
```

## 동작 방식

1. **15번 문항까지 정상 완료**하거나 **40분 초과**로 종료되면
   `useTestStateMachine`이 `isCompleted` 또는 `isForceEnded`를 true로 바꿉니다.
2. `TestScreen`은 두 경우 모두 `ResultScreen`으로 전환합니다.
3. `ResultScreen`에서:
   - 문항별 카드에서 **▶ 재생** 버튼으로 그 자리에서 답변을 다시 들어볼 수 있습니다
     (`Audio.Sound.createAsync({ uri })`, 로컬 파일이므로 네트워크 불필요).
   - **공유하기** 버튼은 `expo-sharing`의 `Sharing.shareAsync(uri)`를 호출해
     안드로이드 기본 공유시트(카카오톡, 이메일, Google Drive, 파일 앱 등)를 띄웁니다.
     사용자가 원하는 곳으로 자유롭게 파일을 내보낼 수 있어 별도 서버가 필요 없습니다.
   - **새 모의고사 시작하기**를 누르면 `TestScreen`의 `sessionKey`가 바뀌며
     `ExamSession` 전체가 리마운트되어 문항 번호, 녹음 목록, 40분 타이머가 모두 깨끗하게 초기화됩니다.

## 설치 추가 사항

```bash
npx expo install expo-sharing
```

## 나중에 실제 백엔드(Firebase/REST API)로 업로드가 필요해지면

`ResultScreen`의 `savedRecordings` (`[{ questionNumber, uri }]`)를 그대로
업로드 함수에 넘기기만 하면 됩니다. 예:

```js
// 예시: Firebase Storage 업로드로 확장하고 싶을 때
import { getStorage, ref, uploadBytesResumable } from 'firebase/storage';
import * as FileSystem from 'expo-file-system';

async function uploadRecording(item) {
  const response = await fetch(item.uri);
  const blob = await response.blob();
  const storage = getStorage();
  const fileRef = ref(storage, `opic/${sessionId}/q${item.questionNumber}.m4a`);
  await uploadBytesResumable(fileRef, blob);
}
```

지금 구조는 `savedRecordings` 배열만 바뀐 함수로 넘기면 되도록 설계되어 있어,
나중에 이 부분만 추가하면 됩니다.
